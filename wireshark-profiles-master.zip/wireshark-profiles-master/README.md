Recommend that you are running Wireshark 2.6.4 before adding these profiles as there maybe some compatability issues on older versions. Keep in mind any changes that you make will be immediately saved. I'll most likely be updating these files when tweaking stuff. You may overwrite changes you've made if you download these again. 

Download this entire respository as a zip file. Once it is unzipped you would be able to put each individual folder into the `profiles` folder of Wireshark. The path can easily be navigated to from Wireshark. Go to About Wireshark > Folders, click on Personal configuration link. You'll then want to open the profiles folder. 

On mac
/Users/username/.config/wireshark/profiles